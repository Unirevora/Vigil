/* Visual settings are independent from the user's journals and backups. */
export const APPEARANCE_KEY='vigil-appearance-v142';
export const DEFAULT_APPEARANCE=Object.freeze({
  accent:'#a83f2a',background:'paper',backgroundOpacity:24,
  surfaceOpacity:91,bodyFontSize:16,lineHeight:2.0,contentWidth:1460,
  texture:true,heroMode:'original',theme:'paper',fontFamily:'heritage'
});
export const COLOR_PRESETS=[
  {name:'朱砂',color:'#a83f2a'}, {name:'松绿',color:'#375d4f'},
  {name:'黛蓝',color:'#49687c'}, {name:'铜金',color:'#8a6535'},
  {name:'梅紫',color:'#795269'}, {name:'墨青',color:'#326c70'}
];
export const BACKGROUND_PRESETS=[
  {key:'paper',name:'旧宣纸',description:'纸纹浅影'},
  {key:'mountains',name:'高清远山',description:'3200px 水墨远景'},
  {key:'sea',name:'深海山色',description:'深绿细雾'},
  {key:'plum',name:'疏梅',description:'梅枝斜影'},
  {key:'bamboo',name:'竹影',description:'叶影婆娑'},
  {key:'waves',name:'海波',description:'青海浪纹'},
  {key:'custom',name:'自选图片',description:'保存在本机'},
  {key:'none',name:'素笺',description:'无装饰背景'}
];
export function normalizeAppearance(input){
  const a={...DEFAULT_APPEARANCE};
  if(!input||typeof input!=='object'||Array.isArray(input))return a;
  if(typeof input.accent==='string'&&/^#[0-9a-fA-F]{6}$/.test(input.accent))a.accent=input.accent.toLowerCase();
  if(BACKGROUND_PRESETS.some(x=>x.key===input.background))a.background=input.background;
  if(['original','custom'].includes(input.heroMode))a.heroMode=input.heroMode;
  if(['paper','night'].includes(input.theme))a.theme=input.theme;
  if(['heritage','song','sans','kai'].includes(input.fontFamily))a.fontFamily=input.fontFamily;
  for(const [key,min,max] of [['backgroundOpacity',0,85],['surfaceOpacity',50,100],
    ['bodyFontSize',13,22],['lineHeight',1.45,2.5],['contentWidth',860,1740]]){
    if(typeof input[key]==='number'&&Number.isFinite(input[key]))a[key]=Math.min(max,Math.max(min,input[key]));
  }
  if(typeof input.texture==='boolean')a.texture=input.texture;
  return a;
}
export function readAppearance(storage){
  try{
    const raw=storage.getItem(APPEARANCE_KEY);
    return normalizeAppearance(raw?JSON.parse(raw):null);
  }catch{return {...DEFAULT_APPEARANCE};}
}
export function writeAppearance(storage,previous,patch){
  const value=normalizeAppearance({...previous,...patch});
  storage.setItem(APPEARANCE_KEY,JSON.stringify(value));
  return value;
}
export const isValidHex=value=>/^#[\da-fA-F]{6}$/.test(String(value||''));
export function hexToRgb(hex){
  return [parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16)];
}
export function mixHex(hex,other,ratio){
  const a=hexToRgb(hex),b=hexToRgb(other);
  return '#'+a.map((value,i)=>Math.round(value*(1-ratio)+b[i]*ratio).toString(16).padStart(2,'0')).join('');
}
export function contrastInk(hex){
  const s=hexToRgb(hex).map(n=>{const c=n/255;return c<=.04045?c/12.92:((c+.055)/1.055)**2.4;});
  return s[0]*.2126+s[1]*.7152+s[2]*.0722>.33?'#222d28':'#fff7e7';
}
